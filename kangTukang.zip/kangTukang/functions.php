<?php

$conn = mysqli_connect("localhost", "root", "", "kangTukang");

function query($syntax)
{
    global $conn;

    $result = mysqli_query($conn, $syntax);

    $rows = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    return $rows;
}

function signUp($syntax)
{
    global $conn;

    mysqli_query($conn, $syntax);

    return mysqli_affected_rows($conn);
}
function addTask($syn){
    global $conn;

    mysqli_query($conn, $syn);

    return mysqli_affected_rows($conn);
}
function addSukses($syn, $taskId){
    global $conn;

    mysqli_query($conn, $syn);
    
    $syntax = "DELETE FROM TASK WHERE taskId = $taskId";
    mysqli_query($conn, $syntax);

    return mysqli_affected_rows($conn);
}
function deleteSukses($syn){
    global $conn;

    mysqli_query($conn, $syn);

    return mysqli_affected_rows($conn);
}
function addOffer($syn){
    global $conn;

    mysqli_query($conn, $syn);

    return mysqli_affected_rows($conn);
}
function deleteTask($id){
    global $conn;
    $syn = "DELETE FROM OFFER WHERE taskId = $id";
    $syntax = "DELETE FROM TASK WHERE taskId = $id";

    mysqli_query($conn,$syn);
    mysqli_query($conn,$syntax);
    return mysqli_affected_rows($conn);
}