<?php
require_once '../functions.php';

$id = $_GET['suksesId'];
$userId = $_GET['userId'];

$syn = "DELETE FROM SUKSES WHERE suksesId = $id";
deleteSukses($syn);

echo "<script>document.location.href='../success.php?idUser=$userId'</script>";