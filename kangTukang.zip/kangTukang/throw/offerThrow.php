<?php
    require_once '../functions.php';
    $taskId = $_GET['taskId'];

    $id = $_GET['idUser'];
    deleteTask($taskId);

    echo "<script>document.location.href='../offered.php?idUser=$id'</script>";