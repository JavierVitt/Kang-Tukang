<?php
require_once '../functions.php';
$workerId = $_GET['workerId'];
$taskId = $_GET['taskId'];
$syn = "SELECT * FROM TASK WHERE taskId = $taskId";
$result = query($syn);
$userId = $result[0]['userId'];
$keluhan = $result[0]['keluhan'];
$harga = $result[0]['harga'];
$lokasi = $result[0]['lokasi'];
$foto = $result[0]['foto'];
$deadline = $result[0]['deadline'];

$syntax = "SELECT * FROM USER WHERE userId = $workerId";
$querrrr = query($syntax);
$namaTukang = $querrrr[0]['username'];

$syntax = "INSERT INTO SUKSES VALUES ('',$userId,'$keluhan',$harga,'$lokasi','$foto','$deadline','$namaTukang')";
addSukses($syntax, $taskId);

echo "<script>document.location.href='../success.php?idUser=$workerId'</script>";